	
	Para compilar y ejecutar el programa, se usa el siguiente comando:
	
	"python3 max_sat.py"