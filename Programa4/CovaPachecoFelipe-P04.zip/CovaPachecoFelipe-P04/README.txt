Compilar dentro del directorio "src" con el comando:
- javac *.java

Ejecutar el programa con el comando:
- java Main