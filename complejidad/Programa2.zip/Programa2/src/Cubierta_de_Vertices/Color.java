/**
 * Enumeración para colores de nodos. Es trivial agregar más colores de ser
 * necesarios.
 */
public enum Color {
    NINGUNO,
    /** Rojo. */
    ROJO,
    /** Negro. */
    NEGRO
}
