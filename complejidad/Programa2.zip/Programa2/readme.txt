Programa 2
Complejidad Computacional
Juan Carlos Montero Santiago 
415122599

Mi representacion de las graficas es una que yo implemente
en un curso pasado de estructuras de datos.
Las clases hechas especificamente para este programa son Cobertura.java
y Programa2.java

INSTRUCCIONES:
1.- Entrar desde la linea de comandos a la carpeta /src
2.- Compilar todos los archivos ejecutando javac *.java
3.- Ejecutar la clase principal Programa2 usando el comando
    java Programa2
4.- En cada ejecucion de este se genera un ejemplar diferente
    del problema, es decir, cada ejecucion se generará una grafica
    diferente y su solucion aproximada.

NOTA:
La grafica se representa en la linea de comandos como su conjunto de vertices
seguido de su lista de adyacencias. Por como implemente las graficas (no dirigidas)
la arista (u,v) y (v,u) seran mostradas aunque esten repetidas.
