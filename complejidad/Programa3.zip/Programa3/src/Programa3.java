public class Programa3{
	public static void main(String[] args) {
		TSP algo = new TSP();

		algo.genetico();
	}
}